﻿"""CLI package."""
