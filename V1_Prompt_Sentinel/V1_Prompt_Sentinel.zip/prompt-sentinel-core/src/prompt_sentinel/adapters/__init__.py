﻿"""Agent-specific adapter helpers."""
